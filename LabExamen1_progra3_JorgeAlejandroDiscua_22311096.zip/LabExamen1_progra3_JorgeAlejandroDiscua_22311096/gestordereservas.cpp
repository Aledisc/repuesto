#include "GestorDeReservas.h"

GestorDeReservas::GestorDeReservas() : contadorReservas(0) {
    // Inicializar con 3 mesas
    mesas.append(Mesa("Mesa 1", "Salón Principal"));
    mesas.append(Mesa("Mesa 2", "Salón Principal"));
    mesas.append(Mesa("Mesa 3", "Salón de Fiestas"));
}
// Agregar una reserva a la lista
void GestorDeReservas::agregarReserva(const Reserva& reserva) {
    reservas.append(reserva);
}

void GestorDeReservas::agregarMesa(const Mesa& mesa) {
    mesas.append(mesa);
}

// Obtener todas las reservas
QList<Reserva> GestorDeReservas::obtenerReservas() const {
    return reservas;
}

QList<Mesa> GestorDeReservas::obtenerMesas() const {
    return mesas;
}

bool GestorDeReservas::eliminarMesa(const QString& nombre) {
    for (int i = 0; i < mesas.size(); ++i) {
        if (mesas[i].getNombre() == nombre) {
            mesas.removeAt(i);
            return true; // Mesa eliminada con éxito
        }
    }
    return false; // Nombre de mesa no encontrado
}

// Buscar una reserva por nombre del representante
Reserva* GestorDeReservas::buscarReservaPorNombre(const QString& nombre) {
    for (Reserva& reserva : reservas) {
        if (reserva.getNombreDelRepresentante() == nombre) {
            return &reserva;
        }
    }
    return nullptr; // No se encontró la reserva
}

// Eliminar una reserva por nombre del representante
bool GestorDeReservas::eliminarReserva(int codigo) {
    for (int i = 0; i < reservas.size(); ++i) {
        if (reservas[i].getCodigo() == codigo) {
            reservas.removeAt(i);
            contadorReservas--;
            return true; // Reserva eliminada con éxito
        }
    }
    return false; // Código no encontrado
}

int GestorDeReservas::getContadorReservas() const {
    return contadorReservas;
}

bool GestorDeReservas::verificarReserva(const QString& nombre, int codigo) const {
    for (const Reserva& reserva : reservas) {
        if (reserva.getCodigo() == codigo) {
            if (reserva.getNombreDelRepresentante() == nombre) {
                return true; // La reserva con el código y nombre coincide
            }
            return false; // El nombre no coincide
        }
    }
    return false; // Código no encontrado
}

void GestorDeReservas::modificarReserva(int codigo, const QString& nombreDelRepresentante, const QString& numeroDeContacto, int comensales, const QDate& fecha, const QTime& hora) {
    for (Reserva& reserva : reservas) {
        if (reserva.getCodigo() == codigo) {
            reserva.setNombreDelRepresentante(nombreDelRepresentante);
            reserva.setNumeroDeContacto(numeroDeContacto);
            reserva.setComensales(comensales);
            reserva.setFecha(fecha);
            reserva.setHora(hora);
            return;
        }
    }

}

void GestorDeReservas::modificarMesa(const QString& nombre, const QString& nuevoNombre, const QString& nuevoSalon) {
    for (Mesa& mesa : mesas) {
        if (mesa.getNombre() == nombre) {
            // Actualizar la mesa
            mesa = Mesa(nuevoNombre, nuevoSalon);
            return; // Modificación exitosa, salir de la función
        }
    }
    // Si el nombre no se encontró, podrías manejar el error aquí si lo deseas
}
