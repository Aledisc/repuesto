#include "reserva.h"

//constructor
Reserva::Reserva(const QString& nombre, const QString& contacto, int comensales, const QDate& fecha, const QTime& hora, int codigo)
    : nombreDelRepresentante(nombre), numeroDeContacto(contacto), comensales(comensales), fecha(fecha), hora(hora), codigo(codigo) {}

//getters
QString Reserva::getNombreDelRepresentante() const {
    return nombreDelRepresentante;
}

QString Reserva::getNumeroDeContacto() const {
    return numeroDeContacto;
}

int Reserva::getComensales() const {
    return comensales;
}

QDate Reserva::getFecha() const {
    return fecha;
}

QTime Reserva::getHora() const {
    return hora;
}

int Reserva::getCodigo() const {
    return codigo;
}

//setters
void Reserva::setNombreDelRepresentante(const QString& nombre) {
    nombreDelRepresentante = nombre;
}

void Reserva::setNumeroDeContacto(const QString& contacto) {
    numeroDeContacto = contacto;
}

void Reserva::setComensales(int comensales) {
    this->comensales = comensales;
}

void Reserva::setFecha(const QDate& fecha) {
    this->fecha = fecha;
}

void Reserva::setHora(const QTime& hora) {
    this->hora = hora;
}
