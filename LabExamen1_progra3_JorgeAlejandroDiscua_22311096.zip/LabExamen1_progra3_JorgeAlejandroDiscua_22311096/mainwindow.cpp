#include "mainwindow.h"
#include "./ui_mainwindow.h"


#include "gestordereservas.h"
#include "reserva.h"
#include "mesa.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

GestorDeReservas gestor;
int codigo = 1;

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_4_clicked()
{
    exit(0);
}


void MainWindow::on_pushButton_12_clicked()
{
    if(!ui->leNombre->text().isEmpty() && !ui->leNumero->text().isEmpty()){
        Reserva reserva1(ui->leNombre->text(), ui->leNumero->text(), ui->sbComensales->value(), ui->calendarCrear->selectedDate(),ui->timeCrear->time(), codigo++);
        gestor.agregarReserva(reserva1);
        ui->leNombre->setText("");
        ui->leNumero->setText("");
        ui->sbComensales->setValue(1);
        QMessageBox::information(this,"Reserva hecha", "Su codigo de reserva es: "+QString::number(reserva1.getCodigo()));
    }else{
        QMessageBox::warning(this,"Error", "Llene todos los espacios vacios");
    }




}


void MainWindow::on_pushButton_15_clicked()
{
    if(!ui->leCodigoEliminar->text().isEmpty() && !ui->leNombreEliminar->text().isEmpty()){
        if(gestor.verificarReserva(ui->leNombreEliminar->text(), ui->leCodigoEliminar->text().toInt())){
            if(gestor.eliminarReserva(ui->leCodigoEliminar->text().toInt())){
                QMessageBox::information(this,"Se ha eliminado", "Se ha eliminado la reserva exitosamente");
                ui->leCodigoEliminar->setText("");
                ui->leNombreEliminar->setText("");
            }else{
                QMessageBox::information(this,"No se encontro", "No se ha encontrado la reserva a eliminar");
            }
        }else{
            QMessageBox::warning(this,"Error", "Alguno de los datos ingresados no coincide");
        }
    }else{
        QMessageBox::warning(this, "Error", "Por favor llene todos los espacios solicitados");
    }
}


void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_13_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void MainWindow::on_pushButton_16_clicked()
{
    if(!ui->leCodigoModificar->text().isEmpty() && !ui->leNombreModificar->text().isEmpty()){
        if(gestor.verificarReserva(ui->leNombreModificar->text(), ui->leCodigoModificar->text().toInt())){
            ui->stackedWidget_3->setCurrentIndex(1);
        }else{
            QMessageBox::warning(this,"Error", "Alguno de los datos ingresados no coincide");
        }
    }else{
        QMessageBox::warning(this, "Error", "Por favor llene todos los espacios solicitados");
    }
}


void MainWindow::on_pushButton_17_clicked()
{
    if(!ui->leNombreMod->text().isEmpty() && !ui->leContactoMod->text().isEmpty()){
        gestor.modificarReserva(ui->leCodigoModificar->text().toInt(),ui->leNombreMod->text(),ui->leContactoMod->text(),ui->sbComensalesMod->value(),ui->calendarMod->selectedDate(),ui->timeMod->time());
        QMessageBox::information(this,"Datos modificados", "Se ha modificado la reserva");
        ui->leNombreMod->setText("");
        ui->leContactoMod->setText("");
        ui->sbComensalesMod->setValue(1);
    }else{
        QMessageBox::warning(this,"Error", "Llene todos los espacios vacios");
    }
}


void MainWindow::on_pushButton_14_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    ui->stackedWidget_3->setCurrentIndex(0);
}


void MainWindow::on_pushButton_8_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void MainWindow::on_pushButton_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void MainWindow::on_pushButton_5_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}


void MainWindow::on_pushButton_6_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(0);
}


void MainWindow::on_pushButton_18_clicked()
{
    Mesa nuevaMesa(ui->leMesaCrear->text(), ui->leSalonMesaCrear->text());
    gestor.agregarMesa(nuevaMesa);
    QMessageBox::information(this,"Se ha creado", "Se ha creado una nueva mesa");
}


void MainWindow::on_pushButton_19_clicked()
{
    gestor.eliminarMesa(ui->leDeshabMesa->text());
    QMessageBox::information(this,"Se ha eliminado", "Se ha eliminado la mesa");
}

